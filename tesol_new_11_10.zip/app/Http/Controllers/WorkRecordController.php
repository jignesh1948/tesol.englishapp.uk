<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\helper;
class WorkRecordController extends Controller
{
    
    
    public function workRecord() {
  //   	$feedBackData = array();
		// $feedBackData['feedback_type'] = "trainer_training";
		// $feedBackData['token_app_type'] = 'tesol';
		// $feedBackData['token'] = Session::get('token_id');
		// $api = "get-feedback-question";
		// $getFeedBack = helper::curl_get($api,$feedBackData);
		return response()->view('trainer.workrecord');
    }
}
