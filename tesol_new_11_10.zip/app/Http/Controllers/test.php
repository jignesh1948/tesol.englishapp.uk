<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Client;

class test extends Controller
{
    public function initdata(Request $request) {
    	
    	$session = json_decode(file_get_contents('http://ec2-3-21-219-82.us-east-2.compute.amazonaws.com/api/session_list?teacher_id=5e2eb5d36383af44fa235a72&token_app_type=tesol&token=5W3SJ9CADFM4UOTB82XIY01VNL'), true);

		return response()->view('trainer.dashboard', compact('session'));
    }
}
