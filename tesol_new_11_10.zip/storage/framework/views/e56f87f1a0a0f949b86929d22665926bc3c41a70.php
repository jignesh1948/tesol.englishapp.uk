	<?php $__env->startSection('content'); ?>
		

			<section class="content">
				<header class="content__title">
					<div class="navigation-trigger hidden-xl-up" data-ma-action="aside-open" data-ma-target=".sidebar">
						<div class="navigation-trigger__inner">
							<i class="navigation-trigger__line"></i>
							<i class="navigation-trigger__line"></i>
							<i class="navigation-trigger__line"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-md-7 col-lg-6 col-xl-6">
							<div class="custom-select-dropdown">
								<select id="trainer" class="select2">
									<?php $__currentLoopData = $session['result']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($sessionId == $data['id']): ?>
											<option value="<?php echo e($data['id']); ?>" selected="true"><?php echo e($data['name']); ?></option>
										<?php else: ?>
											<option value="<?php echo e($data['id']); ?>"><?php echo e($data['name']); ?></option>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-sm-12 col-md-7 col-lg-6 col-xl-6">
							
						</div>
					</div>
					<div class="actions hidden-sm-down">
						<img class="logo__img_right" src="images/header-logo/IEUK-text-logo.png" alt="logo right">
					</div>
				</header>
				<div class="row">
					<div class="col-sm-12 col-md-7 col-lg-6 col-xl-6">
						<div class="tab-container tab-container-heading">
							<ul class="nav nav-tabs nav-tabs-header" role="tablist">
								<li class="nav-item">
									<a class="nav-link active" data-toggle="tab" href="#powerpoint" role="tab">PowerPoint</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" data-toggle="tab" href="#theory" role="tab">Theory</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" data-toggle="tab" href="#video" role="tab">Video</a>
								</li>
							</ul>
							<div class="tab-content">
								<div class="tab-pane active fade show" id="powerpoint" role="tabpanel">
									<div class="row">
										<div class="thumbnail-arrow hidden-xs-down">
											<a href="javascript:void(0)" class="thumb-indicator"><i class="zmdi zmdi-chevron-left"></i><i class="zmdi zmdi-chevron-left"></i></a>
										</div>
										<div class="col-sm-3 col-md-3 col-lg-3 col-xl-3 hidden-xs-down" id="thumb-hide">
											<div id="thumbnail-slider">
												<div class="inner">
													<ul>
														<?php $__currentLoopData = $pptList['result'][0]['ppt_file']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li><a class="thumb" href="<?php echo e($image); ?>"></a></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div>
											</div>
										</div>
										<div class="col-sm-9 col-md-9 col-lg-9 col-xl-9" id="thumb-show">
											<div id="ninja-slider">
												<div class="slider-inner">
													<ul>
														<?php $__currentLoopData = $pptList['result'][0]['ppt_file']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<li><a class="ns-img" href="<?php echo e($image); ?>"></a></li>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
													<div class="fs-icon" title="Expand/Close"></div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<input type="hidden" name="" value="<?php echo e($pptList['result'][0]['id']); ?>" id="ppt_id">
								<input type="hidden" name="" value="<?php echo e($sessionId); ?>" id="sessionId">
								<div class="tab-pane fade" id="theory" role="tabpanel">
									<div class="row">
										<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
											<?php if(isset($pptList['result'][0]['theory_pdf'])): ?>
												<iframe class="pdf-viewer-theory" src="<?php echo e($pptList['result'][0]['theory_pdf']); ?>#pagemode=none" title="webviewer" frameborder="0" width="100%" height="500"></iframe>
											<?php endif; ?>
										</div>
									</div>
								</div>

								<div class="tab-pane fade" id="video" role="tabpanel">
									<!-- <iframe width="100%" height="400" src="<?php echo e($pptList['result'][0]['ppt_video']); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
									<object data="<?php echo e($pptList['result'][0]['ppt_video']); ?>" width="100%" height="400"></object>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-md-5 col-lg-6 col-xl-6">
						<div class="tab-container tab-container-heading">
							<ul class="nav nav-tabs nav-tabs-header" role="tablist">
								<li class="nav-item">
									<a class="nav-link active" data-toggle="tab" href="#trainernotes" role="tab">Trainer Notes</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" data-toggle="tab" href="#notes" role="tab">Notes</a>
								</li>
							</ul>
							<div class="tab-content">
								<div class="tab-pane active fade show" id="trainernotes" role="tabpanel">
									<?php if(isset($sessionNoteList['result']['trainer_manual_pdf'][0])): ?>
										<iframe class="pdf-viewer-trainernotes" src="<?php echo e($sessionNoteList['result']['trainer_manual_pdf'][0]); ?>#pagemode=none" title="webviewer" frameborder="0" width="100%" height="330"></iframe>
									<?php endif; ?>
									<div class="card rounded10 mt-4 mb-3">
										<div class="card-block p-2">
											<div class="form-group mb-0">
												
												<textarea id="note" class="form-control" rows="3" placeholder=""><?php echo e($sessionNoteList['result']['trainer_note'][0]['teacher_note']); ?></textarea>
												<i class="form-group__bar"></i>
											</div>
										</div>
									</div>
									<div class="btn-demo text-center">
										<button type="button" class="btn btn-save waves-effect" id="savenote">Save</button>
									</div>
								</div>
								<div class="tab-pane fade" id="notes" role="tabpanel">
									<div class="card rounded10 mb-3">
										<div class="card-block p-2">
											<div class="form-group mb-0">
												<textarea class="form-control" rows="20" placeholder="" id="note_s"><?php echo e($sessionNoteList['result']['trainer_note'][0]['teacher_note']); ?>	</textarea>
												<i class="form-group__bar"></i>
											</div>
											
										</div>
									</div>
									<div class="btn-demo text-center">
										<button type="button" class="btn btn-save waves-effect" id="savenotes">Save</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</main>


<?php $__env->stopSection(); ?>	

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/3.5.4/select2.css">  
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.5.4/select2.js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/ninja-slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/thumbnail-slider.js')); ?>"></script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#trainer').select2();

			$('#savenote').click(function(){
				var note = $('#note').val();
				commonSave("note_manual",note);
			});
			$('#savenotes').click(function(){
				var note = $('#note_s').val();
				commonSave("note",note);
			})

		});	
		function commonSave(note_type,note){
			var loginData   = {
					sessionId: $('#sessionId').val(),
					note: note,
					note_type: note_type,
					ppt_id: $('#ppt_id').val(),
					api:"add_ppt_note",
				}
				$.ajax({
				url: url + "/addnote",
				type: 'post',
				dataType: 'json',
				contentType: 'application/json',
				success: function (data) {
				   console.log(data);
				},
				data: JSON.stringify(loginData),
				headers: {
				    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
				});
		}
		$(document).on('change','.select2',function(){
			location.href = "?id="+$(this).val();
		});

		
</script>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/tesol_new/resources/views/trainer/dashboard.blade.php ENDPATH**/ ?>