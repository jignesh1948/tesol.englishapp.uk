<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Imperial English UK">
		<meta name="keywords" content="Imperial English UK">
		<meta name="author" content="Imperial English UK">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
		<title>TESOL</title>

	<!-- 	<link rel="stylesheet" href="vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.0.css">
		<link rel="stylesheet" href="vendors/bower_components/jquery.scrollbar/jquery.scrollbar.css">
		<link rel="stylesheet" href="css/app.min.css">
		<link rel="stylesheet" href="css/custom.css">
		<link rel="stylesheet" href="css/ninja-slider.css">
		<link rel="stylesheet" href="css/thumbnail-slider.css">
		<link rel="stylesheet" href="fonts/MyraidPRO/font-style.css"> -->


		<link rel="stylesheet" href="<?php echo e(asset('vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.0.css')); ?>">  
		<link rel="stylesheet" href="<?php echo e(asset('vendors/bower_components/jquery.scrollbar/jquery.scrollbar.css')); ?>">  
		<link rel="stylesheet" href="<?php echo e(asset('css/app.min.css')); ?>">  
		<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">  
		<link rel="stylesheet" href="<?php echo e(asset('css/ninja-slider.css')); ?>">  
		<link rel="stylesheet" href="<?php echo e(asset('css/thumbnail-slider.css')); ?>">  
		<link rel="stylesheet" href="<?php echo e(asset('fonts/MyraidPRO/font-style.css')); ?>">  
		<?php echo $__env->yieldContent('style'); ?>

	</head>
	<body data-ma-theme="heavy-light-blue">
		 <?php $url = env('APP_URL'); ?>
		 <main class="main">
			<aside class="sidebar">
				<div class="menu_logo">
					<img class="menu_top_logo" src="images/header-logo/IEUK-logo.png" alt="logo left">
				</div>
				<div class="scrollbar-inner">
					<ul class="navigation">
						<li class="<?php echo e((Request::is('dashboard') ? 'navigation__active' : '')); ?>"><a href="/dashboard">Home</a></li>
						<li class="<?php echo e((Request::is('profile') ? 'navigation__active' : '')); ?>"><a href="/profile">Profile</a></li>
						<li class="<?php echo e((Request::is('work-record') ? 'navigation__active' : '')); ?>"><a href="work-record">Work Record</a></li>
						<li class="<?php echo e((Request::is('feedback') ? 'navigation__active' : '')); ?>"><a href="/feedback">Feedback</a></li>
						<li><a href="logout.html">Logout</a></li>
					</ul>
				</div>
			</aside>

		<?php echo $__env->yieldContent('content'); ?>
		<script type="text/javascript">
			window.url = "<?php echo e($url); ?>";
		</script>
		<script type="text/javascript" src="<?php echo e(asset('vendors/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('vendors/bower_components/tether/dist/js/tether.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('vendors/bower_components/Waves/dist/waves.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('vendors/bower_components/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('vendors/bower_components/jquery-scrollLock/jquery-scrollLock.min.js')); ?>"></script>

		<script type="text/javascript" src="<?php echo e(asset('js/app.min.js')); ?>"></script>
		<?php echo $__env->yieldContent('scripts'); ?>

	</body>
</html>
<?php /**PATH /var/www/html/tesol_new/resources/views/layout/layout.blade.php ENDPATH**/ ?>