@extends('layout.layout')
@section('content')
		
			<section class="content">
				<header class="content__title">
					<div class="navigation-trigger hidden-xl-up" data-ma-action="aside-open" data-ma-target=".sidebar">
						<div class="navigation-trigger__inner">
							<i class="navigation-trigger__line"></i>
							<i class="navigation-trigger__line"></i>
							<i class="navigation-trigger__line"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-md-7 col-lg-6 col-xl-6">
							<h1 class="page__title">Profile</h1>
						</div>
						<div class="col-sm-12 col-md-7 col-lg-6 col-xl-6">
						</div>
					</div>
					<div class="actions hidden-sm-down">
						<img class="logo__img_right" src="images/header-logo/IEUK-text-logo.png" alt="logo right">
					</div>
				</header>

				<div class="row mt-5 mr-3">
					<div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
						<div class="card rounded20">
							<div class="card-block">
								<div class="card-block-title mb-4">
									<h4>Organisation Details</h4>
								</div>
								<div class="card-block-details profile-details">
									<h6>{{$profileList['org_name']}}</h6>
									<h6>{{$profileList['org_email']}}</h6>
									<h6>{{$profileList['org_mobile']}}</h6>
								</div>
								<div class="card-block-title mt-4">
									<h4>Training Programme</h4>
								</div>
								<div class="card-block-details profile-details">
									<h6>{{$profileList['training_rogramme']}}</h6>
								</div>
								<div class="card-block-title mt-4">
									<h4>Registered Group(s)</h4>
								</div>
								<div class="card-block-details profile-details">
									<h6>Batch 1, Batch 1, Batch 1, Batch 1, Batch 1,Batch 1, Batch 1, Batch 1, Batch 1, Batch 1,</h6>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
						<div class="card rounded20">
							<div class="card-block edit-details">
								<div class="card-block-title mb-4">
									<h4>Your Details</h4>
								</div>
								<div class="row mb-4">
									<div class="col-9 col-sm-9 col-md-9 col-lg-9 col-xl-9">
										<span class="fname-class">{{$profileList['first_name']}}</span>
										<div class="form-group mb-0 collapse fname-text">
											<input type="text" class="form-control text-light-blue" value="{{$profileList['first_name']}}" id="fname">
											<i class="form-group__bar"></i>
											<button class="btn btn-info btn-sm savefname">Save</button>
										</div>
									</div>
									<div class="col-3 col-md-sm col-md-3 col-lg-3 col-xl-3 text-right edit-fname">
										<a href="javascript:void(0)" class="a-theme">Edit</a>
									</div>
								</div>
								<div class="row mb-4">
									<div class="col-9 col-sm-9 col-md-9 col-lg-9 col-xl-9">
										<span class="lname-class">{{$profileList['last_name']}}</span>
										<div class="form-group mb-0 collapse fname lname-text">
											<input type="text" class="form-control text-light-blue" value="{{$profileList['last_name']}}"  id="lname">
											<i class="form-group__bar"></i>
											<button class="btn btn-info btn-sm savelname">Save</button>
										</div>
									</div>
									<div class="col-3 col-md-sm col-md-3 col-lg-3 col-xl-3 text-right edit-lname">
										<a href="javascript:void(0)" class="a-theme">Edit</a>
									</div>
								</div>
								<div class="row mb-4">
									<div class="col-9 col-sm-9 col-md-9 col-lg-9 col-xl-9">
										<span>{{$profileList['email']}}</span>
									</div>
									
								</div>
								<div class="row mb-4">
									<div class="col-9 col-sm-9 col-md-9 col-lg-9 col-xl-9">
										<span class="phone-class">{{$profileList['contact_number']}}</span>
										<div class="form-group mb-0 collapse phone-text">
											<input type="text" class="form-control text-light-blue" value="{{$profileList['contact_number']}}
											" id="phone">
											<i class="form-group__bar"></i>
											<button class="btn btn-info btn-sm savephone">Save</button>
										</div>
									</div>
									<div class="col-3 col-md-sm col-md-3 col-lg-3 col-xl-3 text-right edit-phone">
										<a href="javascript:void(0)" class="a-theme">Edit</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
						<div class="card rounded20">
							<div class="card-block pass-change">
								<div class="card-block-title mb-4">
									<h4>Create a new password</h4>
								</div>
								<h6 class="sub__title mb-3">Current Password</h6>
								<div class="form-group">
									<input type="password" id="old-password" class="form-control" placeholder="Enter old password">
									<i class="form-group__bar"></i>
								</div>
								<h6 class="sub__title mb-3">New Password</h6>
								<div class="form-group mb-3">
									<input type="password" id="new-password" class="form-control" placeholder="Enter new password">
									<i class="form-group__bar"></i>
								</div>
								<div class="form-group">
									<input type="password" id="re-password" class="form-control" placeholder="Retype new password">
									<i class="form-group__bar"></i>
								</div>
								<div class="btn-demo text-center">
									<button type="button" class="btn btn-save waves-effect password_change">Save</button>
								</div>
							</div>
						</div>
						<h6 class="text-center mb-5">View <a href="">Terms & Conditions</a> and <a href="">Privacy Policy</a></h6>
					</div>
				</div>
			</section>
		</main>

	


@stop	

@section('style')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/3.5.4/select2.css">  
@stop	
@section('scripts')
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.5.4/select2.js"></script>


<script type="text/javascript">
		$(document).ready(function(){
			$('#trainer').select2();

			$('#savenote').click(function(){
				var note = $('#note').val();
				commonSave("note_manual",note);
			});
			$('#savenotes').click(function(){
				var note = $('#note_s').val();
				commonSave("note",note);
			});
			$('.edit-fname').click(function(){
				fadeIN('fname-text');
				fadeOUT('fname-class');
			});
			$('.edit-lname').click(function(){
				fadeIN('lname-text');
				fadeOUT('lname-class');
			});
			$('.edit-phone').click(function(){
				fadeIN('phone-text');
				fadeOUT('phone-class');
			});

			$('.password_change').click(function(){
				var old_password 	= $('#old-password').val();
				var new_password 	= $('#new-password').val();
				var re_password 	= $('#re-password').val();
				var fname 			= $('#fname').val();
				var lname 			= $('#lname').val();
				var phone 			= $('#phone').val();

				var data = new Array();
				data['old_password'] = old_password;
				data['new_password'] = new_password;
				data['first_name'] = fname;
				data['last_name'] = lname;
				data['contact_number'] = phone;
				data['api'] = "edit_tesol_profile";
				data['flag'] = "password";
				var newdata = Object.assign({}, data);
				editProfile(newdata);
			});
			$('.savefname,.savelname,.savephone').click(function(){
				var fname 			= $('#fname').val();
				var lname 			= $('#lname').val();
				var phone 			= $('#phone').val();
				var data = new Array();
				data['first_name'] = fname;
				data['last_name'] = lname;
				data['contact_number'] = phone;
				data['flag'] = "profile";
				data['api'] = "edit_tesol_profile";
				var newdata = Object.assign({}, data);
				editProfile(newdata);

				fadeOUT('fname-text');
				fadeIN('fname-class');
				$('.fname-class').text(fname);

				fadeOUT('lname-text');
				fadeIN('lname-class');
				$('.lname-class').text(lname);

				fadeOUT('phone-text');
				fadeIN('phone-class');
				$('.phone-class').text(phone);
			});

		});	



		function fadeIN(selector){		
			$('.'+selector).css("display","block");
		}
		function fadeOUT(selector){
			$('.'+selector).css("display","none");
		}
		function editProfile(data){
			/*var loginData   = {
					sessionId: $('#sessionId').val(),
					note: note,
					note_type: note_type,
					ppt_id: $('#ppt_id').val(),
					api:"add_ppt_note",
				}*/
				console.log(data);
				// return false;
			var loginData   = data
				$.ajax({
				url: url + "/editprofile",
				type: 'post',
				dataType: 'json',
				contentType: 'application/json',
				success: function (data) {
				   console.log(data);
				},
				data: JSON.stringify(loginData),
				headers: {
				    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
				});
		}
		function commonSave(note_type,note){
			var loginData   = {
					sessionId: $('#sessionId').val(),
					note: note,
					note_type: note_type,
					ppt_id: $('#ppt_id').val(),
					api:"add_ppt_note",
				}
				$.ajax({
				url: url + "/addnote",
				type: 'post',
				dataType: 'json',
				contentType: 'application/json',
				success: function (data) {
				   console.log(data);
				},
				data: JSON.stringify(loginData),
				headers: {
				    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
				});
		}
		$(document).on('change','.select2',function(){
			location.href = "?id="+$(this).val();
		});

		
</script>
@stop	